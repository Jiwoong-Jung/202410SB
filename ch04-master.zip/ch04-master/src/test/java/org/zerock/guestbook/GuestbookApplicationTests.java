package org.zerock.guestbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GuestbookApplicationTests {

    @Test
    void contextLoads() {
    }

}
