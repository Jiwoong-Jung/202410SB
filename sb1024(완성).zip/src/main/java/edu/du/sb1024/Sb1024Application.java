package edu.du.sb1024;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb1024Application {

    public static void main(String[] args) {
        SpringApplication.run(Sb1024Application.class, args);
    }

}
