package edu.du.sb1024.spring;

public class WrongIdPasswordException extends RuntimeException {

}
