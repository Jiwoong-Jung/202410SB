package edu.du.sb1024.spring;

public class MemberNotFoundException extends RuntimeException {

}
